package com.example.mariy.heal;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private int Sleep =2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Splash splash = new Splash();
        splash.start();
    }
    private class Splash extends Thread{
        @Override
        public void run() {
            try{
                sleep(1000*Sleep);
            }catch (InterruptedException e){
                e.printStackTrace();
            }
            Intent i = new Intent(MainActivity.this,surgery.class);
            startActivity(i);
            MainActivity.this.finish();;
        }
    }
}
